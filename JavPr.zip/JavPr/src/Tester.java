import java.util.Scanner;

public class Tester {

	

	public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
int n = 4;
n++;
		String text = "I live in BG. I am now in Vratsa";
		System.out.println(n);
		System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	}
}
